using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class knife : MonoBehaviour
{
    [SerializeField]
    private Vector2 throwforce;

    private bool isactive = true;
    private Rigidbody2D rb;
    private BoxCollider2D knifecollider;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        knifecollider = GetComponent<BoxCollider2D>();

    }
    private void Update()
    {
        if (Input.GetMouseButtonDown(0) && isactive)
        {
            rb.AddForce(throwforce, ForceMode2D.Impulse);
            rb.gravityScale = 1;
            gamecontrol.Instance.gameui.decrementdisplayknifecount();
        }
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (!isactive)
            return;
        
        
        isactive = false;


        if (collision.collider.tag == "log")
        {


            rb.velocity = new Vector2(0, 0);
            rb.bodyType = RigidbodyType2D.Kinematic;
            this.transform.SetParent(collision.collider.transform);

            knifecollider.offset = new Vector2(knifecollider.offset.x, -0.4f);
            knifecollider.size = new Vector2(knifecollider.size.x, 1.2f);

            gamecontrol.Instance.onsuccesfulhit();

        }
        else if (collision.collider.tag == "knife")
        {

            rb.velocity = new Vector2(rb.velocity.x, -2);
            gamecontrol.Instance.StartGameOverSeqeunce(false);

        }
    }
}
