using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;



[RequireComponent(typeof(gameui))]
public class gamecontrol : MonoBehaviour
{
    public static gamecontrol Instance { get; private set; }
    [SerializeField]
    private int knifecount = 0;

    [Header("Knife Spawning")]
    [SerializeField]
    private Vector2 KnifeSpawnPos;
    [SerializeField]
    private GameObject knife;


    public gameui gameui { get; private set; }

    private void Awake()
    {
        Instance = this;
        gameui = GetComponent<gameui>();

    }

    private void Start()
    {
        gameui.setintialdisplayknifecount(knifecount);
        spawnknife();
    }

    public void onsuccesfulhit()
    {
        if (knifecount > 0)
        {
            spawnknife();
        }
        else
        {
            StartGameOverSeqeunce(true);
        }
    }

    private void spawnknife()
    {
        knifecount--;
        Instantiate(knife, KnifeSpawnPos, Quaternion.identity);
    }

    public void StartGameOverSeqeunce(bool win)
    {
        StartCoroutine("GameOverSeqeunceCoroutine", win);
         
    }
    
    private IEnumerator GameOverSeqeunceCoroutine(bool win)
    {
        if (win)
        {
            yield return new WaitForSecondsRealtime(0.3f);
            RestartGame();
        }
        else
        {
            gameui.showrestartbutton();
        }
    }
    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex, LoadSceneMode.Single);



    }

}

