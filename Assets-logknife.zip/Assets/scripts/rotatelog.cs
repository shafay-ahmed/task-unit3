using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class logrotation : MonoBehaviour
{
    [System.Serializable]
    private class rotationelement
    {
        public float speed;
        public float duration;
    }

    [SerializeField]
    private rotationelement[] rotationPattern;
    private WheelJoint2D wheeljoint;
    private JointMotor2D jointmotor;

    private void Awake()
    {
        wheeljoint = GetComponent<WheelJoint2D>();
        jointmotor = new JointMotor2D();
        StartCoroutine("playrotationpattern");
    }

    private IEnumerator playrotationpattern()
    {
        int rotationindex = 0;
        while (true)
        {
            yield return new WaitForFixedUpdate();
            jointmotor.motorSpeed = rotationPattern[rotationindex].speed;
            jointmotor.maxMotorTorque = 10000;
            wheeljoint.motor = jointmotor;


            yield return new WaitForSecondsRealtime(rotationPattern[rotationindex].duration);
            rotationindex++;
            rotationindex = rotationindex < rotationPattern.Length ? rotationindex : 0;
        }

    }
}