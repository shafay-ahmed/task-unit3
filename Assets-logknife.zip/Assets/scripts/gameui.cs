using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class gameui : MonoBehaviour
{
    [SerializeField]
    private GameObject Buttonrestart;

    [Header("Knife Count Display")]
    [SerializeField]
    private GameObject knifepanel;
    [SerializeField]
    private GameObject knifeicon;
    [SerializeField]
    private Color usedknifeiconcolor;

    public void showrestartbutton()
    {
        Buttonrestart.SetActive(true);
    }
    public void setintialdisplayknifecount(int count)
    {
        for (int i = 0; i < count; i++) ;
        Instantiate(knifeicon, knifepanel.transform);

    }

    private int knifeiconindextochange = 0;
    public void decrementdisplayknifecount()
    {
        knifepanel.transform.GetChild(knifeiconindextochange++);
        GetComponent<Image>().color = usedknifeiconcolor;
    }
}
