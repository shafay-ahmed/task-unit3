using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy : MonoBehaviour
{
    public float circleSpeed = 20f;
    private float minX, maxX, minY, maxY;

    void Start()
    {
        Rigidbody2D rb = GetComponent<Rigidbody2D>();
        rb.velocity = Vector2.down * circleSpeed;

        Camera cam = Camera.main;
        float camHeight = cam.orthographicSize;
        float camWidth = camHeight * cam.aspect;


        // Calculate boundaries based on camera position and size
        minX = -camWidth;
        maxX = camWidth;
        minY = -camHeight;
        maxY = camHeight;
    }

    void Update()
    {
        if (transform.position.y < -5)
        {
            // Reverse the direction when it hits the ground
            Rigidbody2D rb = GetComponent<Rigidbody2D>();
            rb.velocity = new Vector2(rb.velocity.x, circleSpeed);
        }


        // Get the current position of the circle
        Vector3 newPosition = transform.position;

        // Clamp the position to stay within the camera boundaries
        newPosition.x = Mathf.Clamp(newPosition.x, minX, maxX);
        newPosition.y = Mathf.Clamp(newPosition.y, minY, maxY);

        // Update the position of the circle
        transform.position = newPosition;

    }
}
  

    
