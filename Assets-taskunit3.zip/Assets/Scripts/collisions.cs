using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class collisions : MonoBehaviour
{
    public GameObject smallCirclePrefab;
    public float splitForce = 2.0f;

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Square"))
        {
            if (gameObject.CompareTag("BigCircle"))
            {
                // Split the big circle if it's larger than a certain size
                if (transform.localScale.x > 0.1f)
                {
                    // Instantiate two smaller circles
                    GameObject smallCircle1 = Instantiate(smallCirclePrefab, transform.position + Vector3.left * 0.5f, Quaternion.identity);
                    GameObject smallCircle2 = Instantiate(smallCirclePrefab, transform.position + Vector3.right * 0.5f, Quaternion.identity);

                    // Apply a split force to the smaller circles
                    Rigidbody2D rb1 = smallCircle1.GetComponent<Rigidbody2D>();
                    Rigidbody2D rb2 = smallCircle2.GetComponent<Rigidbody2D>();
                    rb1.AddForce(Vector2.up * splitForce, ForceMode2D.Impulse);
                    rb2.AddForce(Vector2.up * splitForce, ForceMode2D.Impulse);
                }
            }
        }
    }
}
