using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shooting : MonoBehaviour
{
    public GameObject squarePrefab;
    public float shootingForce = 10f;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Shoot();
        }
    }

    void Shoot()
    {
        GameObject square = Instantiate(squarePrefab, transform.position, Quaternion.identity);
        Rigidbody2D rb = square.GetComponent<Rigidbody2D>();
        rb.AddForce(Vector2.up * shootingForce, ForceMode2D.Impulse);
    }
}
